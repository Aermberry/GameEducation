var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Ui;
(function (Ui) {
    var Introduction = (function (_super) {
        __extends(Introduction, _super);
        function Introduction() {
            var _this = _super.call(this) || this;
            _this.skinName = "IntroductionSkin";
            return _this;
        }
        Introduction.prototype.partAdded = function (partName, instance) {
            _super.prototype.partAdded.call(this, partName, instance);
        };
        Introduction.prototype.childrenCreated = function () {
            _super.prototype.childrenCreated.call(this);
            this.textLabel.text = this.text;
            this.textLabel.size = this.fontSize;
            this.textLabel2.text = this.text2;
            this.textLabel2.size = this.fontSize2;
        };
        Object.defineProperty(Introduction.prototype, "text", {
            get: function () {
                return this._text;
            },
            // text
            set: function (value) {
                this._text = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Introduction.prototype, "fontSize", {
            get: function () {
                return this._fontSize;
            },
            // fintSize
            set: function (value) {
                this._fontSize = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Introduction.prototype, "text2", {
            get: function () {
                return this._text2;
            },
            set: function (value) {
                this._text2 = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Introduction.prototype, "fontSize2", {
            get: function () {
                return this._fontSize2;
            },
            // fintSize
            set: function (value) {
                this._fontSize2 = value;
            },
            enumerable: true,
            configurable: true
        });
        return Introduction;
    }(eui.Component));
    Ui.Introduction = Introduction;
    __reflect(Introduction.prototype, "Ui.Introduction", ["eui.UIComponent", "egret.DisplayObject"]);
})(Ui || (Ui = {}));
//# sourceMappingURL= Introduction.js.map